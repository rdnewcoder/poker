INSTRUCTIONS
-------------------------------------------------------------------------------------------------------------------------------------------------------------------

INSTALLATION PROCEDURE:

- Upload all files and product license to the directory of your choice. Your license can be generated and downloaded from your client account at http://www.onlinepokerscript.com


SELF INSTALLER

- CHMOD includes/config.php to 777

- Run Installer

- CHMOD includes/config.php to 644

- CHMOD avatars directory to 777.

If you have problems with the installer you can manually install (see below).



MANUAL INSTALLATION

- Insert data from poker.sql into your db.

- edit includes/config.php to add your db connection info and administrator username

- CHMOD includes/config.php to 644

- CHMOD avatars directory to 777.



